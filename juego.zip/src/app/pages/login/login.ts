import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrls: ['./login.scss'],
})
export class LoginComponent {
  mostrarPassword = false;
  form: FormGroup;

  constructor(private fb: FormBuilder, private router: Router) {
    this.form = this.fb.group({
      correo: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }

  campo(nombre: string) {
    return this.form.get(nombre)!;
  }

  togglePassword() {
    this.mostrarPassword = !this.mostrarPassword;
  }

  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const { correo } = this.form.value;

    // ⚠ Simulación de login – sólo frontend
    const usuario = {
      correo,
      logueado: true,
      fechaLogin: new Date().toISOString(),
    };

    localStorage.setItem('usuario', JSON.stringify(usuario));

    console.log('Login OK, usuario guardado en localStorage:', usuario);

    // Redirigir a home (o donde quieras)
    this.router.navigate(['/']);
  }
}
