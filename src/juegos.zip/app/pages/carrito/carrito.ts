import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Cart, CartItem } from '../../core/cart'; // Importa CartItem y Cart
import { Observable } from 'rxjs'; // Importa Observable

@Component({
  selector: 'app-carrito',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './carrito.html',
  styleUrls: ['./carrito.scss'],
})
export class CarritoComponent {
  // Se declara la propiedad sin inicialización inmediata
  carrito$: Observable<CartItem[]>;
  carritoLista: CartItem[] = [];

  constructor(public cart: Cart) {
    // Se inicializa en el constructor, donde 'cart' ya está disponible.
    this.carrito$ = this.cart.carrito$;
    // Mantener copia segura para la plantilla
    this.carrito$.subscribe((items) => {
      this.carritoLista = items ?? [];
    });
  }

  total() {
    return this.cart.total();
  }
  envio() {
    return this.cart.envio();
  }

  totalFinal() {
    return this.cart.totalFinal();
  }
}

