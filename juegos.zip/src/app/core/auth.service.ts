import { Injectable } from '@angular/core';
import { AuthRepository } from './auth.repository';
import { Usuario } from './auth';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private usuarioActual = new BehaviorSubject<Usuario | null>(null);
  usuarioActual$ = this.usuarioActual.asObservable();

  constructor(private repo: AuthRepository) {
    const guardado = localStorage.getItem('usuarioActual');
    if (guardado) this.usuarioActual.next(JSON.parse(guardado));
  }

  private guardarSesion(u: Usuario) {
    localStorage.setItem('usuarioActual', JSON.stringify(u));
    this.usuarioActual.next(u);
  }

  // =====================================
  // LOGIN
  // =====================================
  login(correo: string, clave: string): Usuario | null {
    const u = this.repo.buscarPorCredenciales(correo, clave);
    if (!u) return null;

    this.guardarSesion(u);
    return u;
  }

  // =====================================
  // REGISTRO
  // =====================================
  registrar(data: Usuario): boolean {
    const ok = this.repo.registrar(data);
    return ok;
  }

  // =====================================
  // PERFIL
  // =====================================
  actualizarUsuario(data: Usuario) {
    const ok = this.repo.actualizarUsuario(data);
    if (ok) this.guardarSesion(data);
    return ok;
  }

  cambiarClave(correo: string, actual: string, nueva: string): boolean {
    return this.repo.cambiarClave(correo, actual, nueva);
  }

  // =====================================
  // SESIÓN
  // =====================================
  getUsuarioActual(): Usuario | null {
    return this.usuarioActual.value;
  }

  logout() {
    localStorage.removeItem('usuarioActual');
    this.usuarioActual.next(null);
  }
}
