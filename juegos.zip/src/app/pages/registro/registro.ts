import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  Validators,
  ReactiveFormsModule,
  AbstractControl,
  ValidationErrors,
  FormGroup,
} from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { Usuario } from '../../core/auth';

@Component({
  selector: 'app-registro',
  standalone: true,
  templateUrl: './registro.html',
  styleUrls: ['./registro.scss'],
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
})
export class RegistroComponent {
  form!: FormGroup;

  verClave = false;
  verClave2 = false;

  mensajeExito = false;
  errorMsg = '';

  constructor(private fb: FormBuilder, private router: Router, private auth: AuthService) {
    this.form = this.fb.group(
      {
        nombre: ['', [Validators.required, Validators.minLength(3)]],
        usuario: ['', [Validators.required, Validators.minLength(3)]],
        correo: ['', [Validators.required, Validators.email]],

        clave: [
          '',
          [
            Validators.required,
            Validators.minLength(6),
            this.uppercaseValidator(),
            this.numberValidator(),
            this.specialValidator(),
          ],
        ],

        repetirClave: ['', Validators.required],

        fechaNacimiento: ['', Validators.required],
        direccion: [''],
      },
      { validators: this.clavesIgualesValidator() }
    );
  }

  // -----------------------------
  // GETTER
  campo(nombre: string): AbstractControl {
    return this.form.get(nombre)!;
  }

  // -----------------------------
  // VALIDADORES PERSONALIZADOS
  uppercaseValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      const v = control.value || '';
      return /[A-Z]/.test(v) ? null : { uppercase: true };
    };
  }

  numberValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      const v = control.value || '';
      return /[0-9]/.test(v) ? null : { number: true };
    };
  }

  specialValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      const v = control.value || '';
      return /[^A-Za-z0-9]/.test(v) ? null : { special: true };
    };
  }

  clavesIgualesValidator() {
    return (group: AbstractControl): ValidationErrors | null => {
      const c1 = group.get('clave')?.value;
      const c2 = group.get('repetirClave')?.value;
      return c1 === c2 ? null : { noCoinciden: true };
    };
  }

  // -----------------------------
  // SUBMIT
  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const data: Usuario = {
      nombre: this.form.value.nombre,
      usuario: this.form.value.usuario,
      correo: this.form.value.correo,
      fechaNacimiento: this.form.value.fechaNacimiento,
      direccion: this.form.value.direccion,
      clave: this.form.value.clave,
      rol: 'cliente',
    };

    try {
      this.auth.registrar(data);
      this.mensajeExito = true;

      setTimeout(() => {
        this.router.navigate(['/login']);
      }, 1800);
    } catch (e: any) {
      this.errorMsg = e.message ?? 'Error desconocido';
    }
  }

  // -----------------------------
  // LIMPIAR FORMULARIO 
  limpiar() {
    this.form.reset();
    this.form.markAsPristine();
    this.form.markAsUntouched();
    this.errorMsg = '';
  }
}
